import React, { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { api } from '../api.js';

const STATUS_LABELS = {
  pending: 'Pending Confirmation',
  confirmed: 'Confirmed',
  paid: 'Paid',
  cancelled: 'Cancelled',
  completed: 'Completed',
};

export default function ClientDashboard() {
  const { user, token } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    api.getMyBookings(token).then((data) => setBookings(data.bookings)).catch((e) => setError(e.message));
  }, [token]);

  return (
    <div className="section">
      <h1>Welcome, {user?.name}</h1>
      <p className="muted">Here are your treks and their current status.</p>
      {error && <p className="error">{error}</p>}

      {bookings.length === 0 && <p>You have no bookings yet. Head to the <a href="/treks">Treks</a> page to book your first adventure.</p>}

      <div className="bookings-list">
        {bookings.map((b) => (
          <div className="card booking-card" key={b.id}>
            <div className="booking-card-header">
              <h3>{b.trek?.title}</h3>
              <span className={`status-badge status-${b.status}`}>{STATUS_LABELS[b.status] || b.status}</span>
            </div>
            {b.departure && (
              <p className="muted">Dates: {b.departure.start_date} → {b.departure.end_date}</p>
            )}
            <p>Guests: {b.num_adults} adult(s){b.num_children ? `, ${b.num_children} child(ren)` : ''}</p>
            <p>Total: KSh {b.total_price?.toLocaleString()}</p>
            <p>Payment: {b.payment_method.replace('_', ' ')} — <strong>{b.payment_status}</strong></p>
            {b.notes && <p className="muted">Your notes: {b.notes}</p>}
            {b.admin_notes && <p className="admin-note">Note from our team: {b.admin_notes}</p>}
          </div>
        ))}
      </div>
    </div>
  );
}
