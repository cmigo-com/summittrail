import React, { useState } from 'react';
import AdminOverview from '../components/admin/AdminOverview.jsx';
import AdminBookings from '../components/admin/AdminBookings.jsx';
import AdminTreks from '../components/admin/AdminTreks.jsx';
import AdminClients from '../components/admin/AdminClients.jsx';

const TABS = [
  { key: 'overview', label: 'Overview' },
  { key: 'bookings', label: 'Bookings' },
  { key: 'treks', label: 'Treks' },
  { key: 'clients', label: 'Clients' },
];

export default function AdminDashboard() {
  const [tab, setTab] = useState('overview');

  return (
    <div className="section admin-dashboard">
      <h1>Admin Dashboard</h1>
      <div className="tabs">
        {TABS.map((t) => (
          <button
            key={t.key}
            className={`tab ${tab === t.key ? 'tab-active' : ''}`}
            onClick={() => setTab(t.key)}
          >
            {t.label}
          </button>
        ))}
      </div>

      <div className="tab-content">
        {tab === 'overview' && <AdminOverview />}
        {tab === 'bookings' && <AdminBookings />}
        {tab === 'treks' && <AdminTreks />}
        {tab === 'clients' && <AdminClients />}
      </div>
    </div>
  );
}
