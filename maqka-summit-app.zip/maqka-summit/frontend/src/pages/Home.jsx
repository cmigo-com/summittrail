import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';

export default function Home() {
  const [treks, setTreks] = useState([]);

  useEffect(() => {
    api.getTreks().then((data) => setTreks(data.treks.slice(0, 3))).catch(() => {});
  }, []);

  return (
    <div>
      <section className="hero">
        <div className="hero-content">
          <p className="eyebrow">Explore. Experience. Conquer.</p>
          <h1>Trek Kenya's Highest Peaks with Confidence</h1>
          <p className="hero-lead">
            Guided mountain treks up Mount Kenya and beyond — expert guides, safety-first
            acclimatization plans, and unforgettable summit sunrises.
          </p>
          <div className="hero-actions">
            <Link to="/treks" className="btn btn-primary">Explore Treks</Link>
            <Link to="/register" className="btn btn-outline">Create an Account</Link>
          </div>
        </div>
      </section>

      <section className="section">
        <h2>Why Trek With Us</h2>
        <div className="grid-3">
          <div className="card">
            <h3>Expert Guides</h3>
            <p>Our guides know every route on the mountain and prioritize your safety at altitude.</p>
          </div>
          <div className="card">
            <h3>Acclimatization First</h3>
            <p>Every itinerary is built to give your body time to adjust — the summit can wait.</p>
          </div>
          <div className="card">
            <h3>Full Support</h3>
            <p>Porters, cooks, camping gear, and emergency evacuation protocols on every trek.</p>
          </div>
        </div>
      </section>

      <section className="section">
        <h2>Featured Treks</h2>
        <div className="grid-3">
          {treks.map((t) => (
            <div className="card trek-card" key={t.id}>
              <h3>{t.title}</h3>
              <p className="muted">{t.location} · {t.duration_days} days</p>
              <p>{t.description?.slice(0, 100)}...</p>
              <p className="price">From KSh {t.price_adult.toLocaleString()}</p>
              <Link to={`/treks/${t.slug}`} className="btn btn-outline btn-sm">View Details</Link>
            </div>
          ))}
          {treks.length === 0 && <p>No treks published yet.</p>}
        </div>
      </section>
    </div>
  );
}
