import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api.js';

export default function Treks() {
  const [treks, setTreks] = useState([]);
  const [error, setError] = useState('');

  useEffect(() => {
    api.getTreks().then((data) => setTreks(data.treks)).catch((e) => setError(e.message));
  }, []);

  return (
    <div className="section">
      <h1>Our Treks</h1>
      {error && <p className="error">{error}</p>}
      <div className="grid-3">
        {treks.map((t) => (
          <div className="card trek-card" key={t.id}>
            <h3>{t.title}</h3>
            <p className="muted">{t.location} · {t.duration_days} days · {t.difficulty}</p>
            <p>{t.description?.slice(0, 120)}...</p>
            <p className="price">Adult: KSh {t.price_adult.toLocaleString()} {t.price_child ? `· Child: KSh ${t.price_child.toLocaleString()}` : ''}</p>
            <p className="muted">{t.departures?.length || 0} upcoming departure(s)</p>
            <Link to={`/treks/${t.slug}`} className="btn btn-primary btn-sm">View & Book</Link>
          </div>
        ))}
        {treks.length === 0 && !error && <p>Loading treks...</p>}
      </div>
    </div>
  );
}
