import React, { useEffect, useState } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { api } from '../api.js';
import { useAuth } from '../context/AuthContext.jsx';

export default function TrekDetail() {
  const { slug } = useParams();
  const { user, token } = useAuth();
  const navigate = useNavigate();

  const [trek, setTrek] = useState(null);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [form, setForm] = useState({ departure_id: '', num_adults: 1, num_children: 0, notes: '', payment_method: 'bank_transfer' });

  useEffect(() => {
    api.getTrek(slug).then((data) => {
      setTrek(data.trek);
      if (data.trek.departures?.length) {
        setForm((f) => ({ ...f, departure_id: data.trek.departures[0].id }));
      }
    }).catch((e) => setError(e.message));
  }, [slug]);

  function updateForm(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleBook(e) {
    e.preventDefault();
    setError('');
    setSuccess('');

    if (!user) {
      navigate('/login', { state: { from: `/treks/${slug}` } });
      return;
    }

    try {
      await api.createBooking(
        {
          trek_id: trek.id,
          departure_id: form.departure_id || null,
          num_adults: Number(form.num_adults),
          num_children: Number(form.num_children),
          notes: form.notes,
          payment_method: form.payment_method,
        },
        token
      );
      setSuccess('Booking request submitted! We will confirm by email/phone and share bank transfer details.');
    } catch (err) {
      setError(err.message);
    }
  }

  if (error && !trek) return <p className="error section">{error}</p>;
  if (!trek) return <p className="section">Loading trek...</p>;

  return (
    <div className="section trek-detail">
      <Link to="/treks" className="back-link">← Back to Treks</Link>
      <h1>{trek.title}</h1>
      <p className="muted">{trek.location} · {trek.route} · {trek.duration_days} days · {trek.difficulty}</p>
      {trek.max_altitude_m && <p className="muted">Max altitude: {trek.max_altitude_m}m</p>}
      <p>{trek.description}</p>

      {trek.highlights?.length > 0 && (
        <>
          <h3>Highlights</h3>
          <ul>
            {trek.highlights.map((h, i) => <li key={i}>{h}</li>)}
          </ul>
        </>
      )}

      <div className="booking-box">
        <h3>Book This Trek</h3>
        <p className="price">Adult: KSh {trek.price_adult.toLocaleString()} {trek.price_child ? `· Child: KSh ${trek.price_child.toLocaleString()}` : ''}</p>

        {error && <p className="error">{error}</p>}
        {success && <p className="success">{success}</p>}

        {!success && (
          <form onSubmit={handleBook} className="form">
            {trek.departures?.length > 0 && (
              <label>
                Departure date
                <select value={form.departure_id} onChange={(e) => updateForm('departure_id', e.target.value)}>
                  {trek.departures.map((d) => (
                    <option key={d.id} value={d.id}>
                      {d.start_date} → {d.end_date} ({d.slots_available} slots left)
                    </option>
                  ))}
                </select>
              </label>
            )}
            {(!trek.departures || trek.departures.length === 0) && (
              <p className="muted">No fixed departure dates yet — contact us for a custom date.</p>
            )}

            <div className="form-row">
              <label>
                Adults
                <input type="number" min="1" value={form.num_adults} onChange={(e) => updateForm('num_adults', e.target.value)} />
              </label>
              <label>
                Children
                <input type="number" min="0" value={form.num_children} onChange={(e) => updateForm('num_children', e.target.value)} />
              </label>
            </div>

            <label>
              Payment method
              <select value={form.payment_method} onChange={(e) => updateForm('payment_method', e.target.value)}>
                <option value="bank_transfer">Bank Transfer</option>
                <option value="cash">Cash</option>
              </select>
            </label>

            <label>
              Notes (dietary needs, fitness level, etc.)
              <textarea value={form.notes} onChange={(e) => updateForm('notes', e.target.value)} rows={3} />
            </label>

            <button type="submit" className="btn btn-primary">
              {user ? 'Request Booking' : 'Login to Book'}
            </button>
          </form>
        )}
      </div>
    </div>
  );
}
