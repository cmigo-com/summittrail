const BASE_URL = '/api';

async function request(path, { method = 'GET', body, token } = {}) {
  const headers = { 'Content-Type': 'application/json' };
  if (token) headers.Authorization = `Bearer ${token}`;

  const res = await fetch(`${BASE_URL}${path}`, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    throw new Error(data.error || `Request failed with status ${res.status}`);
  }
  return data;
}

export const api = {
  register: (payload) => request('/auth/register', { method: 'POST', body: payload }),
  login: (payload) => request('/auth/login', { method: 'POST', body: payload }),
  me: (token) => request('/auth/me', { token }),

  getTreks: () => request('/treks'),
  getTrek: (slug) => request(`/treks/${slug}`),
  createTrek: (payload, token) => request('/treks', { method: 'POST', body: payload, token }),
  updateTrek: (id, payload, token) => request(`/treks/${id}`, { method: 'PUT', body: payload, token }),
  deleteTrek: (id, token) => request(`/treks/${id}`, { method: 'DELETE', token }),
  addDeparture: (trekId, payload, token) =>
    request(`/treks/${trekId}/departures`, { method: 'POST', body: payload, token }),

  createBooking: (payload, token) => request('/bookings', { method: 'POST', body: payload, token }),
  getMyBookings: (token) => request('/bookings/mine', { token }),
  getAllBookings: (token, status) => request(`/bookings${status ? `?status=${status}` : ''}`, { token }),
  updateBooking: (id, payload, token) => request(`/bookings/${id}`, { method: 'PUT', body: payload, token }),
  cancelBooking: (id, token) => request(`/bookings/${id}`, { method: 'DELETE', token }),

  getAdminStats: (token) => request('/admin/stats', { token }),
  getClients: (token) => request('/admin/clients', { token }),
};
