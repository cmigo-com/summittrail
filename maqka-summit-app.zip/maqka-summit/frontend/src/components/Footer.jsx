import React from 'react';

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer-inner">
        <div>
          <h4>Maqka Summit Adventures and Tours</h4>
          <p>Explore. Experience. Conquer.</p>
        </div>
        <div>
          <h5>Contact</h5>
          <p>Phone: 0700 000 000</p>
          <p>Email: info@maqkasummit.com</p>
        </div>
        <div>
          <h5>Payments</h5>
          <p>Bank transfer or cash on booking confirmation.</p>
        </div>
      </div>
      <p className="footer-copy">© {new Date().getFullYear()} Maqka Summit Adventures and Tours. All rights reserved.</p>
    </footer>
  );
}
