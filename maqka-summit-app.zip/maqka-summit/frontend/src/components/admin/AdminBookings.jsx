import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { api } from '../../api.js';

const STATUS_OPTIONS = ['pending', 'confirmed', 'paid', 'completed', 'cancelled'];
const PAYMENT_STATUS_OPTIONS = ['unpaid', 'partial', 'paid'];

export default function AdminBookings() {
  const { token } = useAuth();
  const [bookings, setBookings] = useState([]);
  const [filter, setFilter] = useState('');
  const [error, setError] = useState('');
  const [savingId, setSavingId] = useState(null);

  function load() {
    api.getAllBookings(token, filter || undefined).then((data) => setBookings(data.bookings)).catch((e) => setError(e.message));
  }

  useEffect(() => { load(); }, [token, filter]);

  async function updateField(booking, field, value) {
    setSavingId(booking.id);
    try {
      const data = await api.updateBooking(booking.id, { [field]: value }, token);
      setBookings((prev) => prev.map((b) => (b.id === booking.id ? data.booking : b)));
    } catch (e) {
      setError(e.message);
    } finally {
      setSavingId(null);
    }
  }

  async function saveAdminNote(booking, note) {
    await updateField(booking, 'admin_notes', note);
  }

  async function handleCancel(booking) {
    if (!confirm(`Cancel booking for ${booking.client?.name}?`)) return;
    try {
      await api.cancelBooking(booking.id, token);
      load();
    } catch (e) {
      setError(e.message);
    }
  }

  return (
    <div>
      <div className="filters">
        <label>
          Filter by status:
          <select value={filter} onChange={(e) => setFilter(e.target.value)}>
            <option value="">All</option>
            {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </label>
      </div>

      {error && <p className="error">{error}</p>}

      <div className="table-wrap">
        <table className="admin-table">
          <thead>
            <tr>
              <th>Client</th>
              <th>Trek</th>
              <th>Dates</th>
              <th>Guests</th>
              <th>Total</th>
              <th>Status</th>
              <th>Payment</th>
              <th>Admin Note</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {bookings.map((b) => (
              <tr key={b.id} className={savingId === b.id ? 'row-saving' : ''}>
                <td>
                  <div>{b.client?.name}</div>
                  <div className="muted small">{b.client?.email}</div>
                  <div className="muted small">{b.client?.phone}</div>
                </td>
                <td>{b.trek?.title}</td>
                <td>{b.departure ? `${b.departure.start_date} → ${b.departure.end_date}` : '—'}</td>
                <td>{b.num_adults}A{b.num_children ? ` / ${b.num_children}C` : ''}</td>
                <td>KSh {b.total_price?.toLocaleString()}</td>
                <td>
                  <select value={b.status} onChange={(e) => updateField(b, 'status', e.target.value)}>
                    {STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </td>
                <td>
                  <select value={b.payment_status} onChange={(e) => updateField(b, 'payment_status', e.target.value)}>
                    {PAYMENT_STATUS_OPTIONS.map((s) => <option key={s} value={s}>{s}</option>)}
                  </select>
                </td>
                <td>
                  <input
                    defaultValue={b.admin_notes || ''}
                    placeholder="Add note..."
                    onBlur={(e) => saveAdminNote(b, e.target.value)}
                  />
                </td>
                <td>
                  <button className="btn-link danger" onClick={() => handleCancel(b)}>Cancel</button>
                </td>
              </tr>
            ))}
            {bookings.length === 0 && (
              <tr><td colSpan={9}>No bookings found.</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
