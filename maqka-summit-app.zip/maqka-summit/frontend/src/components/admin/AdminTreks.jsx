import React, { useEffect, useState } from 'react';
import { useAuth } from '../../context/AuthContext.jsx';
import { api } from '../../api.js';

const EMPTY_FORM = {
  title: '', slug: '', location: '', route: '', duration_days: 1, difficulty: 'Moderate',
  max_altitude_m: '', price_adult: '', price_child: '', max_guests: 20, description: '', image_url: '',
};

export default function AdminTreks() {
  const { token } = useAuth();
  const [treks, setTreks] = useState([]);
  const [form, setForm] = useState(EMPTY_FORM);
  const [editingId, setEditingId] = useState(null);
  const [error, setError] = useState('');
  const [depForm, setDepForm] = useState({});

  function load() {
    api.getTreks().then((data) => setTreks(data.treks)).catch((e) => setError(e.message));
  }

  useEffect(() => { load(); }, []);

  function updateForm(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  function startEdit(trek) {
    setEditingId(trek.id);
    setForm({
      title: trek.title, slug: trek.slug, location: trek.location || '', route: trek.route || '',
      duration_days: trek.duration_days || 1, difficulty: trek.difficulty || 'Moderate',
      max_altitude_m: trek.max_altitude_m || '', price_adult: trek.price_adult, price_child: trek.price_child || '',
      max_guests: trek.max_guests || 20, description: trek.description || '', image_url: trek.image_url || '',
    });
  }

  function resetForm() {
    setEditingId(null);
    setForm(EMPTY_FORM);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError('');
    const payload = {
      ...form,
      duration_days: Number(form.duration_days),
      max_altitude_m: form.max_altitude_m ? Number(form.max_altitude_m) : null,
      price_adult: Number(form.price_adult),
      price_child: form.price_child ? Number(form.price_child) : null,
      max_guests: Number(form.max_guests),
    };
    try {
      if (editingId) {
        await api.updateTrek(editingId, payload, token);
      } else {
        await api.createTrek(payload, token);
      }
      resetForm();
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleDelete(trek) {
    if (!confirm(`Deactivate "${trek.title}"?`)) return;
    try {
      await api.deleteTrek(trek.id, token);
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleAddDeparture(trekId) {
    const dep = depForm[trekId];
    if (!dep?.start_date || !dep?.end_date || !dep?.slots_available) {
      setError('Fill in start date, end date and slots to add a departure.');
      return;
    }
    try {
      await api.addDeparture(trekId, {
        start_date: dep.start_date,
        end_date: dep.end_date,
        slots_available: Number(dep.slots_available),
      }, token);
      setDepForm((f) => ({ ...f, [trekId]: {} }));
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  return (
    <div>
      {error && <p className="error">{error}</p>}

      <div className="card">
        <h3>{editingId ? 'Edit Trek' : 'Add New Trek'}</h3>
        <form onSubmit={handleSubmit} className="form form-grid">
          <label>Title <input required value={form.title} onChange={(e) => updateForm('title', e.target.value)} /></label>
          <label>Slug (url) <input required value={form.slug} onChange={(e) => updateForm('slug', e.target.value)} /></label>
          <label>Location <input value={form.location} onChange={(e) => updateForm('location', e.target.value)} /></label>
          <label>Route <input value={form.route} onChange={(e) => updateForm('route', e.target.value)} /></label>
          <label>Duration (days) <input type="number" min="1" value={form.duration_days} onChange={(e) => updateForm('duration_days', e.target.value)} /></label>
          <label>
            Difficulty
            <select value={form.difficulty} onChange={(e) => updateForm('difficulty', e.target.value)}>
              <option>Easy</option><option>Moderate</option><option>Challenging</option><option>Strenuous</option>
            </select>
          </label>
          <label>Max altitude (m) <input type="number" value={form.max_altitude_m} onChange={(e) => updateForm('max_altitude_m', e.target.value)} /></label>
          <label>Price - Adult (KSh) <input required type="number" value={form.price_adult} onChange={(e) => updateForm('price_adult', e.target.value)} /></label>
          <label>Price - Child (KSh) <input type="number" value={form.price_child} onChange={(e) => updateForm('price_child', e.target.value)} /></label>
          <label>Max guests <input type="number" value={form.max_guests} onChange={(e) => updateForm('max_guests', e.target.value)} /></label>
          <label>Image URL <input value={form.image_url} onChange={(e) => updateForm('image_url', e.target.value)} /></label>
          <label className="full-width">
            Description
            <textarea rows={3} value={form.description} onChange={(e) => updateForm('description', e.target.value)} />
          </label>
          <div className="form-actions full-width">
            <button type="submit" className="btn btn-primary">{editingId ? 'Save Changes' : 'Create Trek'}</button>
            {editingId && <button type="button" className="btn btn-outline" onClick={resetForm}>Cancel Edit</button>}
          </div>
        </form>
      </div>

      <h3>Existing Treks</h3>
      <div className="admin-trek-list">
        {treks.map((t) => (
          <div className="card" key={t.id}>
            <div className="booking-card-header">
              <h4>{t.title}</h4>
              <div>
                <button className="btn-link" onClick={() => startEdit(t)}>Edit</button>
                <button className="btn-link danger" onClick={() => handleDelete(t)}>Deactivate</button>
              </div>
            </div>
            <p className="muted">{t.location} · {t.duration_days} days · KSh {t.price_adult.toLocaleString()}</p>

            <p className="small-heading">Upcoming departures</p>
            <ul className="departure-list">
              {t.departures?.map((d) => (
                <li key={d.id}>{d.start_date} → {d.end_date} ({d.slots_available} slots)</li>
              ))}
              {(!t.departures || t.departures.length === 0) && <li className="muted">None scheduled</li>}
            </ul>

            <div className="form-row small-form">
              <input
                type="date"
                value={depForm[t.id]?.start_date || ''}
                onChange={(e) => setDepForm((f) => ({ ...f, [t.id]: { ...f[t.id], start_date: e.target.value } }))}
              />
              <input
                type="date"
                value={depForm[t.id]?.end_date || ''}
                onChange={(e) => setDepForm((f) => ({ ...f, [t.id]: { ...f[t.id], end_date: e.target.value } }))}
              />
              <input
                type="number"
                placeholder="Slots"
                min="1"
                value={depForm[t.id]?.slots_available || ''}
                onChange={(e) => setDepForm((f) => ({ ...f, [t.id]: { ...f[t.id], slots_available: e.target.value } }))}
              />
              <button className="btn btn-sm btn-outline" onClick={() => handleAddDeparture(t.id)}>Add Date</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
