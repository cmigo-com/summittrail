import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Navbar() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  function handleLogout() {
    logout();
    navigate('/');
  }

  return (
    <header className="navbar">
      <div className="navbar-inner">
        <Link to="/" className="brand">
          <span className="brand-title">MAQKA SUMMIT</span>
          <span className="brand-sub">Adventures &amp; Tours</span>
        </Link>
        <nav className="nav-links">
          <Link to="/">Home</Link>
          <Link to="/treks">Treks</Link>
          {!user && <Link to="/login">Login</Link>}
          {!user && <Link to="/register" className="btn-link">Sign Up</Link>}
          {user && user.role === 'client' && <Link to="/dashboard">My Bookings</Link>}
          {user && user.role === 'admin' && <Link to="/admin">Admin</Link>}
          {user && (
            <button className="btn-link" onClick={handleLogout}>
              Logout
            </button>
          )}
        </nav>
      </div>
    </header>
  );
}
