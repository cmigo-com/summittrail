require('dotenv').config();
const { v4: uuid } = require('uuid');
const bcrypt = require('bcryptjs');
const db = require('./index');

function upsertAdmin() {
  const email = process.env.ADMIN_EMAIL || 'admin@maqkasummit.com';
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existing) {
    console.log('Admin already exists:', email);
    return;
  }
  const password = process.env.ADMIN_PASSWORD || 'ChangeMe123!';
  const hash = bcrypt.hashSync(password, 10);
  db.prepare(
    `INSERT INTO users (id, name, email, phone, password_hash, role) VALUES (?, ?, ?, ?, ?, 'admin')`
  ).run(uuid(), 'Maqka Admin', email, '0700000000', hash);
  console.log('Created admin user:', email, '/ password:', password);
}

function seedTreks() {
  const count = db.prepare('SELECT COUNT(*) as c FROM treks').get().c;
  if (count > 0) {
    console.log('Treks already seeded.');
    return;
  }

  const treks = [
    {
      title: 'Mount Kenya - Sirimon to Chogoria Route',
      slug: 'mt-kenya-sirimon-chogoria',
      location: 'Mount Kenya National Park',
      route: 'Sirimon In / Chogoria Out',
      duration_days: 5,
      difficulty: 'Challenging',
      max_altitude_m: 4985,
      price_adult: 45000,
      price_child: 35000,
      max_guests: 12,
      description:
        'A classic traverse of Mount Kenya climbing up through Sirimon and descending via the dramatic Chogoria route, summiting Point Lenana at 4,985m. Features giant lobelias, groundsels, and stunning views of Batian and Nelion peaks.',
      highlights: JSON.stringify([
        'Summit Point Lenana (4,985m)',
        'Traverse two scenic routes',
        'Afro-alpine flora: giant groundsels & lobelias',
        'Experienced guides, porters & cook',
        'Acclimatization-first itinerary',
      ]),
      image_url: '/images/mt-kenya-peaks.jpg',
    },
    {
      title: 'Mount Kenya - Naromoru Route',
      slug: 'mt-kenya-naromoru',
      location: 'Mount Kenya National Park',
      route: 'Naromoru Gate',
      duration_days: 4,
      difficulty: 'Moderate',
      max_altitude_m: 4985,
      price_adult: 38000,
      price_child: 28000,
      max_guests: 15,
      description:
        'The most direct route up Mount Kenya via Naromoru Gate, passing the Met Station and the famous "vertical bog" before reaching Point Lenana. A faster option for trekkers on a tighter schedule.',
      highlights: JSON.stringify([
        'Shortest route to Point Lenana',
        'Pass Met Station and Mackinders Camp',
        'Great for trekkers with limited time',
        'Full camping gear provided',
      ]),
      image_url: '/images/mt-kenya-signpost.jpg',
    },
    {
      title: 'Mount Kenya - Sirimon Round Trip',
      slug: 'mt-kenya-sirimon-round-trip',
      location: 'Mount Kenya National Park',
      route: 'Sirimon In / Sirimon Out',
      duration_days: 4,
      difficulty: 'Moderate',
      max_altitude_m: 4985,
      price_adult: 36000,
      price_child: 27000,
      max_guests: 15,
      description:
        'A gentler gradient in and out via Sirimon, ideal for first-time high-altitude trekkers, with excellent acclimatization stops at Old Moses and Shipton\\'s Camp.',
      highlights: JSON.stringify([
        'Gradual ascent profile, easier on the body',
        'Camp beneath the dramatic Mount Kenya peaks',
        'Ideal for first-time high-altitude trekkers',
      ]),
      image_url: '/images/shiptons-camp.jpg',
    },
    {
      title: 'Mount Longonot Day Hike',
      slug: 'mount-longonot-day-hike',
      location: 'Mount Longonot National Park',
      route: 'Crater Rim Circuit',
      duration_days: 1,
      difficulty: 'Easy',
      max_altitude_m: 2776,
      price_adult: 4500,
      price_child: 3500,
      max_guests: 30,
      description:
        'A perfect day trip for beginners - hike to the crater rim of this dormant volcano with panoramic views of the Great Rift Valley.',
      highlights: [
        'Great Rift Valley views',
        'Half-day option available',
        'No prior trekking experience needed',
      ],
      image_url: '/images/longonot.jpg',
    },
  ];

  const insert = db.prepare(`
    INSERT INTO treks (id, title, slug, location, route, duration_days, difficulty, max_altitude_m, price_adult, price_child, max_guests, description, highlights, image_url)
    VALUES (@id, @title, @slug, @location, @route, @duration_days, @difficulty, @max_altitude_m, @price_adult, @price_child, @max_guests, @description, @highlights, @image_url)
  `);

  const insertDeparture = db.prepare(`
    INSERT INTO departures (id, trek_id, start_date, end_date, slots_available)
    VALUES (?, ?, ?, ?, ?)
  `);

  for (const t of treks) {
    const id = uuid();
    insert.run({
      ...t,
      id,
      highlights: typeof t.highlights === 'string' ? t.highlights : JSON.stringify(t.highlights),
    });

    // Add two upcoming sample departures per trek
    const today = new Date();
    for (let i = 1; i <= 2; i++) {
      const start = new Date(today);
      start.setDate(start.getDate() + i * 21);
      const end = new Date(start);
      end.setDate(end.getDate() + t.duration_days - 1);
      insertDeparture.run(
        uuid(),
        id,
        start.toISOString().slice(0, 10),
        end.toISOString().slice(0, 10),
        t.max_guests
      );
    }
  }

  console.log(`Seeded ${treks.length} treks with sample departures.`);
}

upsertAdmin();
seedTreks();
console.log('Seeding complete.');
