const Database = require('better-sqlite3');
const path = require('path');

const db = new Database(path.join(__dirname, 'maqka.sqlite'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

db.exec(`
CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'client', -- 'client' | 'admin'
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS treks (
  id TEXT PRIMARY KEY,
  title TEXT NOT NULL,
  slug TEXT UNIQUE NOT NULL,
  location TEXT,
  route TEXT,
  duration_days INTEGER,
  difficulty TEXT, -- 'Easy' | 'Moderate' | 'Challenging' | 'Strenuous'
  max_altitude_m INTEGER,
  price_adult REAL NOT NULL,
  price_child REAL,
  max_guests INTEGER DEFAULT 20,
  description TEXT,
  highlights TEXT, -- JSON array as text
  image_url TEXT,
  is_active INTEGER DEFAULT 1,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS departures (
  id TEXT PRIMARY KEY,
  trek_id TEXT NOT NULL REFERENCES treks(id) ON DELETE CASCADE,
  start_date TEXT NOT NULL,
  end_date TEXT NOT NULL,
  slots_available INTEGER NOT NULL,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS bookings (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  trek_id TEXT NOT NULL REFERENCES treks(id),
  departure_id TEXT REFERENCES departures(id),
  num_adults INTEGER DEFAULT 1,
  num_children INTEGER DEFAULT 0,
  total_price REAL,
  status TEXT NOT NULL DEFAULT 'pending', -- pending | confirmed | paid | cancelled | completed
  payment_method TEXT DEFAULT 'bank_transfer', -- bank_transfer | cash
  payment_status TEXT DEFAULT 'unpaid', -- unpaid | partial | paid
  notes TEXT,
  admin_notes TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  updated_at TEXT DEFAULT (datetime('now'))
);
`);

module.exports = db;
