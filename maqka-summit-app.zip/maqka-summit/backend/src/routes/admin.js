const express = require('express');
const db = require('../db');
const { requireAuth, requireAdmin } = require('../middleware/auth');

const router = express.Router();

router.use(requireAuth, requireAdmin);

router.get('/stats', (req, res) => {
  const totalBookings = db.prepare('SELECT COUNT(*) c FROM bookings').get().c;
  const pending = db.prepare("SELECT COUNT(*) c FROM bookings WHERE status = 'pending'").get().c;
  const confirmed = db.prepare("SELECT COUNT(*) c FROM bookings WHERE status = 'confirmed'").get().c;
  const paidRevenue = db.prepare("SELECT COALESCE(SUM(total_price), 0) s FROM bookings WHERE payment_status = 'paid'").get().s;
  const totalClients = db.prepare("SELECT COUNT(*) c FROM users WHERE role = 'client'").get().c;
  const totalTreks = db.prepare('SELECT COUNT(*) c FROM treks WHERE is_active = 1').get().c;
  const upcomingDepartures = db.prepare("SELECT COUNT(*) c FROM departures WHERE start_date >= date('now')").get().c;

  res.json({
    totalBookings, pending, confirmed, paidRevenue, totalClients, totalTreks, upcomingDepartures,
  });
});

router.get('/clients', (req, res) => {
  const rows = db.prepare("SELECT id, name, email, phone, created_at FROM users WHERE role = 'client' ORDER BY created_at DESC").all();
  res.json({ clients: rows });
});

module.exports = router;
