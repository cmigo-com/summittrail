const express = require('express');
const { v4: uuid } = require('uuid');
const db = require('../db');
const { requireAuth, requireAdmin } = require('../middleware/auth');

const router = express.Router();

function enrichBooking(row) {
  if (!row) return row;
  const trek = db.prepare('SELECT id, title, slug, image_url, duration_days FROM treks WHERE id = ?').get(row.trek_id);
  const departure = row.departure_id
    ? db.prepare('SELECT * FROM departures WHERE id = ?').get(row.departure_id)
    : null;
  const client = db.prepare('SELECT id, name, email, phone FROM users WHERE id = ?').get(row.user_id);
  return { ...row, trek, departure, client };
}

// Client: create a booking
router.post('/', requireAuth, (req, res) => {
  const { trek_id, departure_id, num_adults = 1, num_children = 0, notes, payment_method } = req.body;
  if (!trek_id) return res.status(400).json({ error: 'trek_id is required' });

  const trek = db.prepare('SELECT * FROM treks WHERE id = ?').get(trek_id);
  if (!trek) return res.status(404).json({ error: 'Trek not found' });

  if (departure_id) {
    const dep = db.prepare('SELECT * FROM departures WHERE id = ? AND trek_id = ?').get(departure_id, trek_id);
    if (!dep) return res.status(404).json({ error: 'Departure date not found for this trek' });
    if (dep.slots_available < num_adults + num_children) {
      return res.status(400).json({ error: 'Not enough slots available for this departure date' });
    }
    db.prepare('UPDATE departures SET slots_available = slots_available - ? WHERE id = ?')
      .run(num_adults + num_children, departure_id);
  }

  const totalPrice = (trek.price_adult * num_adults) + ((trek.price_child || 0) * num_children);
  const id = uuid();
  db.prepare(`
    INSERT INTO bookings (id, user_id, trek_id, departure_id, num_adults, num_children, total_price, notes, payment_method)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(id, req.user.id, trek_id, departure_id || null, num_adults, num_children, totalPrice, notes || null, payment_method || 'bank_transfer');

  const row = db.prepare('SELECT * FROM bookings WHERE id = ?').get(id);
  res.status(201).json({ booking: enrichBooking(row) });
});

// Client: view own bookings
router.get('/mine', requireAuth, (req, res) => {
  const rows = db.prepare('SELECT * FROM bookings WHERE user_id = ? ORDER BY created_at DESC').all(req.user.id);
  res.json({ bookings: rows.map(enrichBooking) });
});

// Client: view a single booking they own (or admin can view any)
router.get('/:id', requireAuth, (req, res) => {
  const row = db.prepare('SELECT * FROM bookings WHERE id = ?').get(req.params.id);
  if (!row) return res.status(404).json({ error: 'Booking not found' });
  if (row.user_id !== req.user.id && req.user.role !== 'admin') {
    return res.status(403).json({ error: 'Not authorized to view this booking' });
  }
  res.json({ booking: enrichBooking(row) });
});

// Admin: view all bookings, optional ?status= filter
router.get('/', requireAuth, requireAdmin, (req, res) => {
  const { status } = req.query;
  const rows = status
    ? db.prepare('SELECT * FROM bookings WHERE status = ? ORDER BY created_at DESC').all(status)
    : db.prepare('SELECT * FROM bookings ORDER BY created_at DESC').all();
  res.json({ bookings: rows.map(enrichBooking) });
});

// Admin: update a booking (status, payment_status, admin_notes, dates, etc.)
router.put('/:id', requireAuth, requireAdmin, (req, res) => {
  const existing = db.prepare('SELECT * FROM bookings WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Booking not found' });

  const fields = ['status', 'payment_status', 'payment_method', 'admin_notes', 'num_adults', 'num_children', 'total_price', 'departure_id'];
  const updates = {};
  for (const f of fields) {
    if (req.body[f] !== undefined) updates[f] = req.body[f];
  }
  updates.updated_at = new Date().toISOString();

  const setClause = Object.keys(updates).map((k) => `${k} = @${k}`).join(', ');
  db.prepare(`UPDATE bookings SET ${setClause} WHERE id = @id`).run({ ...updates, id: req.params.id });

  const row = db.prepare('SELECT * FROM bookings WHERE id = ?').get(req.params.id);
  res.json({ booking: enrichBooking(row) });
});

// Admin: cancel a booking and release slots
router.delete('/:id', requireAuth, requireAdmin, (req, res) => {
  const existing = db.prepare('SELECT * FROM bookings WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Booking not found' });

  if (existing.departure_id && existing.status !== 'cancelled') {
    db.prepare('UPDATE departures SET slots_available = slots_available + ? WHERE id = ?')
      .run(existing.num_adults + existing.num_children, existing.departure_id);
  }
  db.prepare("UPDATE bookings SET status = 'cancelled', updated_at = ? WHERE id = ?")
    .run(new Date().toISOString(), req.params.id);

  res.json({ success: true });
});

module.exports = router;
