const express = require('express');
const { v4: uuid } = require('uuid');
const db = require('../db');
const { requireAuth, requireAdmin } = require('../middleware/auth');

const router = express.Router();

function parseTrek(row) {
  if (!row) return row;
  let highlights = [];
  try {
    highlights = JSON.parse(row.highlights || '[]');
  } catch (e) {
    highlights = [];
  }
  return { ...row, highlights };
}

// Public: list active treks with their upcoming departures
router.get('/', (req, res) => {
  const treks = db.prepare('SELECT * FROM treks WHERE is_active = 1 ORDER BY created_at DESC').all();
  const departureStmt = db.prepare(
    "SELECT * FROM departures WHERE trek_id = ? AND start_date >= date('now') ORDER BY start_date ASC"
  );
  const result = treks.map((t) => ({
    ...parseTrek(t),
    departures: departureStmt.all(t.id),
  }));
  res.json({ treks: result });
});

// Public: get single trek by slug
router.get('/:slug', (req, res) => {
  const row = db.prepare('SELECT * FROM treks WHERE slug = ?').get(req.params.slug);
  if (!row) return res.status(404).json({ error: 'Trek not found' });
  const departures = db
    .prepare("SELECT * FROM departures WHERE trek_id = ? AND start_date >= date('now') ORDER BY start_date ASC")
    .all(row.id);
  res.json({ trek: { ...parseTrek(row), departures } });
});

// Admin: create trek
router.post('/', requireAuth, requireAdmin, (req, res) => {
  const {
    title, slug, location, route, duration_days, difficulty,
    max_altitude_m, price_adult, price_child, max_guests,
    description, highlights, image_url,
  } = req.body;

  if (!title || !slug || !price_adult) {
    return res.status(400).json({ error: 'title, slug and price_adult are required' });
  }

  const id = uuid();
  db.prepare(`
    INSERT INTO treks (id, title, slug, location, route, duration_days, difficulty, max_altitude_m, price_adult, price_child, max_guests, description, highlights, image_url)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(
    id, title, slug, location || null, route || null, duration_days || null, difficulty || null,
    max_altitude_m || null, price_adult, price_child || null, max_guests || 20,
    description || null, JSON.stringify(highlights || []), image_url || null
  );

  const row = db.prepare('SELECT * FROM treks WHERE id = ?').get(id);
  res.status(201).json({ trek: parseTrek(row) });
});

// Admin: update trek
router.put('/:id', requireAuth, requireAdmin, (req, res) => {
  const existing = db.prepare('SELECT * FROM treks WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Trek not found' });

  const fields = [
    'title', 'slug', 'location', 'route', 'duration_days', 'difficulty',
    'max_altitude_m', 'price_adult', 'price_child', 'max_guests',
    'description', 'image_url', 'is_active',
  ];
  const updates = {};
  for (const f of fields) {
    if (req.body[f] !== undefined) updates[f] = req.body[f];
  }
  if (req.body.highlights !== undefined) {
    updates.highlights = JSON.stringify(req.body.highlights);
  }

  const setClause = Object.keys(updates).map((k) => `${k} = @${k}`).join(', ');
  if (setClause) {
    db.prepare(`UPDATE treks SET ${setClause} WHERE id = @id`).run({ ...updates, id: req.params.id });
  }

  const row = db.prepare('SELECT * FROM treks WHERE id = ?').get(req.params.id);
  res.json({ trek: parseTrek(row) });
});

// Admin: delete (soft-delete) trek
router.delete('/:id', requireAuth, requireAdmin, (req, res) => {
  const existing = db.prepare('SELECT * FROM treks WHERE id = ?').get(req.params.id);
  if (!existing) return res.status(404).json({ error: 'Trek not found' });
  db.prepare('UPDATE treks SET is_active = 0 WHERE id = ?').run(req.params.id);
  res.json({ success: true });
});

// Admin: add a departure date to a trek
router.post('/:id/departures', requireAuth, requireAdmin, (req, res) => {
  const { start_date, end_date, slots_available } = req.body;
  if (!start_date || !end_date || !slots_available) {
    return res.status(400).json({ error: 'start_date, end_date and slots_available are required' });
  }
  const trek = db.prepare('SELECT id FROM treks WHERE id = ?').get(req.params.id);
  if (!trek) return res.status(404).json({ error: 'Trek not found' });

  const id = uuid();
  db.prepare(
    'INSERT INTO departures (id, trek_id, start_date, end_date, slots_available) VALUES (?, ?, ?, ?, ?)'
  ).run(id, req.params.id, start_date, end_date, slots_available);

  res.status(201).json({ departure: db.prepare('SELECT * FROM departures WHERE id = ?').get(id) });
});

module.exports = router;
